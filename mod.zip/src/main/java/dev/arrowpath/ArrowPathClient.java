package dev.arrowpath;

import java.util.ArrayList;
import java.util.List;
import java.util.OptionalDouble;
import java.util.OptionalInt;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.VertexFormat;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MappableRingBuffer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.Identifier;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;

/**
 * Arrow Path: while you draw a bow, shows the exact flight path and landing spot.
 * The part of the path hidden behind blocks is still shown, just dimmer.
 */
public class ArrowPathClient implements ClientModInitializer {
	public static final String MOD_ID = "arrowpath";

	// ---- Look & feel (change these if you want) ----
	private static final double LINE_HALF_WIDTH = 0.03;   // line thickness
	private static final float ALPHA_VISIBLE = 0.90f;     // part you can see directly
	private static final float ALPHA_HIDDEN = 0.22f;      // part behind blocks
	private static final int MAX_TICKS = 300;             // max simulated flight time
	private static final double SKIP_NEAR_CAMERA = 2.0;   // hide line right in front of your face

	// Pipeline that respects depth (hidden behind blocks gets covered)
	private static final RenderPipeline PIPE_NORMAL = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(MOD_ID, "pipeline/path_normal"))
			.build()
	);

	// Pipeline that ignores depth (draws through blocks)
	private static final RenderPipeline PIPE_THROUGH = RenderPipelines.register(
		RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
			.withLocation(Identifier.fromNamespaceAndPath(MOD_ID, "pipeline/path_through_walls"))
			.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
			.build()
	);

	private final Batch visible = new Batch(PIPE_NORMAL);
	private final Batch hidden = new Batch(PIPE_THROUGH);

	@Override
	public void onInitializeClient() {
		WorldRenderEvents.BEFORE_TRANSLUCENT.register(this::onRender);
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
			visible.close();
			hidden.close();
		});
	}

	// ------------------------------------------------------------------
	// Simulation
	// ------------------------------------------------------------------

	private record Path(List<Vec3> points, BlockHitResult hit, float power) {}

	private static Path simulate(Minecraft mc, LocalPlayer player, float partialTick) {
		if (!player.isUsingItem()) return null;
		ItemStack stack = player.getUseItem();
		if (!stack.is(Items.BOW)) return null;

		// Same formula the vanilla bow uses
		float f = player.getTicksUsingItem() / 20.0f;
		f = (f * f + f * 2.0f) / 3.0f;
		if (f < 0.1f) return null;     // vanilla doesn't fire below this
		if (f > 1.0f) f = 1.0f;

		Level level = player.level();
		Vec3 pos = player.getEyePosition(partialTick).subtract(0.0, 0.1, 0.0);
		Vec3 look = player.getViewVector(partialTick);
		Vec3 vel = look.scale(3.0 * f);

		// Arrows inherit the shooter's movement
		Vec3 move = player.getDeltaMovement();
		vel = vel.add(move.x, player.onGround() ? 0.0 : move.y, move.z);

		List<Vec3> points = new ArrayList<>();
		points.add(pos);

		for (int i = 0; i < MAX_TICKS; i++) {
			Vec3 next = pos.add(vel);

			BlockHitResult hit = level.clip(new ClipContext(
				pos, next, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
			if (hit.getType() != HitResult.Type.MISS) {
				points.add(hit.getLocation());
				return new Path(points, hit, f);
			}

			points.add(next);

			boolean inWater = level.getFluidState(BlockPos.containing(next)).is(FluidTags.WATER);
			vel = vel.scale(inWater ? 0.6 : 0.99);
			vel = vel.add(0.0, -0.05, 0.0);
			pos = next;

			if (next.y < -80.0) break;
		}
		return new Path(points, null, f);
	}

	// ------------------------------------------------------------------
	// Rendering
	// ------------------------------------------------------------------

	private void onRender(WorldRenderContext context) {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer player = mc.player;
		if (player == null || mc.level == null) return;

		float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);
		Path path = simulate(mc, player, partialTick);
		if (path == null) return;

		Vec3 cam = context.worldState().cameraRenderState.pos;
		Matrix4fc matrix = context.matrices().last().pose();

		// Color: orange when weak -> green when full power
		float p = path.power();
		float r = lerp(1.0f, 0.25f, p);
		float g = lerp(0.55f, 1.0f, p);
		float b = lerp(0.10f, 0.55f, p);

		fill(visible.buffer(), matrix, cam, path, r, g, b, ALPHA_VISIBLE);
		fill(hidden.buffer(), matrix, cam, path, r, g, b, ALPHA_HIDDEN);

		// Dim "through walls" layer first, then the bright normal layer on top
		hidden.flush(mc);
		visible.flush(mc);
	}

	private static float lerp(float a, float b, float t) {
		return a + (b - a) * t;
	}

	private static void fill(BufferBuilder buf, Matrix4fc m, Vec3 cam, Path path,
							 float r, float g, float b, float a) {
		List<Vec3> pts = path.points();

		// The flight line
		for (int i = 0; i < pts.size() - 1; i++) {
			Vec3 p0 = pts.get(i);
			Vec3 p1 = pts.get(i + 1);
			if (p0.distanceToSqr(cam) < SKIP_NEAR_CAMERA * SKIP_NEAR_CAMERA) continue;
			ribbon(buf, m, cam, p0, p1, r, g, b, a);
		}

		// Landing marker
		BlockHitResult hit = path.hit();
		if (hit != null) {
			Direction d = hit.getDirection();
			Vec3 n = new Vec3(d.getStepX(), d.getStepY(), d.getStepZ());
			Vec3 u;
			Vec3 w;
			if (d.getAxis() == Direction.Axis.Y) {
				u = new Vec3(1, 0, 0);
				w = new Vec3(0, 0, 1);
			} else if (d.getAxis() == Direction.Axis.X) {
				u = new Vec3(0, 1, 0);
				w = new Vec3(0, 0, 1);
			} else {
				u = new Vec3(1, 0, 0);
				w = new Vec3(0, 1, 0);
			}

			Vec3 c = hit.getLocation().add(n.scale(0.02));
			double size = 0.32;   // half size of the square
			double t = 0.035;     // outline thickness (half)

			// Four sides of the square outline
			rect(buf, m, cam, c.add(w.scale(size)), u, w, size + t, t, r, g, b, a);
			rect(buf, m, cam, c.subtract(w.scale(size)), u, w, size + t, t, r, g, b, a);
			rect(buf, m, cam, c.add(u.scale(size)), u, w, t, size + t, r, g, b, a);
			rect(buf, m, cam, c.subtract(u.scale(size)), u, w, t, size + t, r, g, b, a);
			// Small center dot
			rect(buf, m, cam, c, u, w, 0.05, 0.05, r, g, b, a);
		}
	}

	/** A thin ribbon that always faces the camera, so the line looks the same from any angle. */
	private static void ribbon(BufferBuilder buf, Matrix4fc m, Vec3 cam, Vec3 a, Vec3 c,
							   float r, float g, float b, float al) {
		Vec3 dir = c.subtract(a);
		Vec3 toMid = a.add(c).scale(0.5).subtract(cam);
		Vec3 side = dir.cross(toMid);
		double len = side.length();
		if (len < 1.0e-6) return;
		side = side.scale(LINE_HALF_WIDTH / len);

		quad(buf, m, cam, a.add(side), a.subtract(side), c.subtract(side), c.add(side), r, g, b, al);
	}

	/** Flat rectangle centered at c, spanned by u and w with half sizes hu and hw. */
	private static void rect(BufferBuilder buf, Matrix4fc m, Vec3 cam, Vec3 c, Vec3 u, Vec3 w,
							 double hu, double hw, float r, float g, float b, float al) {
		Vec3 du = u.scale(hu);
		Vec3 dw = w.scale(hw);
		quad(buf, m, cam,
			c.add(du).add(dw),
			c.subtract(du).add(dw),
			c.subtract(du).subtract(dw),
			c.add(du).subtract(dw),
			r, g, b, al);
	}

	/** Adds a quad with both windings, so it shows from either side regardless of culling. */
	private static void quad(BufferBuilder buf, Matrix4fc m, Vec3 cam, Vec3 a, Vec3 b, Vec3 c, Vec3 d,
							 float r, float g, float bl, float al) {
		vertex(buf, m, cam, a, r, g, bl, al);
		vertex(buf, m, cam, b, r, g, bl, al);
		vertex(buf, m, cam, c, r, g, bl, al);
		vertex(buf, m, cam, d, r, g, bl, al);

		vertex(buf, m, cam, d, r, g, bl, al);
		vertex(buf, m, cam, c, r, g, bl, al);
		vertex(buf, m, cam, b, r, g, bl, al);
		vertex(buf, m, cam, a, r, g, bl, al);
	}

	private static void vertex(BufferBuilder buf, Matrix4fc m, Vec3 cam, Vec3 p,
							   float r, float g, float b, float a) {
		buf.addVertex(m, (float) (p.x - cam.x), (float) (p.y - cam.y), (float) (p.z - cam.z))
			.setColor(r, g, b, a);
	}

	// ------------------------------------------------------------------
	// GPU upload + draw (pattern from the official Fabric 1.21.11 docs)
	// ------------------------------------------------------------------

	private static final class Batch {
		private static final Vector4f COLOR_MODULATOR = new Vector4f(1f, 1f, 1f, 1f);
		private static final Vector3f MODEL_OFFSET = new Vector3f();
		private static final Matrix4f TEXTURE_MATRIX = new Matrix4f();

		private final RenderPipeline pipeline;
		private final ByteBufferBuilder allocator = new ByteBufferBuilder(RenderType.SMALL_BUFFER_SIZE);
		private BufferBuilder buffer;
		private MappableRingBuffer vertexBuffer;

		Batch(RenderPipeline pipeline) {
			this.pipeline = pipeline;
		}

		BufferBuilder buffer() {
			if (buffer == null) {
				buffer = new BufferBuilder(allocator, pipeline.getVertexFormatMode(), pipeline.getVertexFormat());
			}
			return buffer;
		}

		void flush(Minecraft client) {
			if (buffer == null) return;

			MeshData built = buffer.buildOrThrow();
			buffer = null;
			MeshData.DrawState params = built.drawState();
			VertexFormat format = params.format();

			GpuBuffer vertices = upload(params, format, built);
			draw(client, built, params, vertices, format);

			vertexBuffer.rotate();
		}

		private GpuBuffer upload(MeshData.DrawState params, VertexFormat format, MeshData built) {
			int size = params.vertexCount() * format.getVertexSize();

			if (vertexBuffer == null || vertexBuffer.size() < size) {
				if (vertexBuffer != null) vertexBuffer.close();
				vertexBuffer = new MappableRingBuffer(
					() -> MOD_ID + " path vertices",
					GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_MAP_WRITE,
					size);
			}

			CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
			try (GpuBuffer.MappedView view = encoder.mapBuffer(
				vertexBuffer.currentBuffer().slice(0, built.vertexBuffer().remaining()), false, true)) {
				MemoryUtil.memCopy(built.vertexBuffer(), view.data());
			}
			return vertexBuffer.currentBuffer();
		}

		private void draw(Minecraft client, MeshData built, MeshData.DrawState params,
						  GpuBuffer vertices, VertexFormat format) {
			GpuBuffer indices;
			VertexFormat.IndexType indexType;

			if (pipeline.getVertexFormatMode() == VertexFormat.Mode.QUADS) {
				built.sortQuads(allocator, RenderSystem.getProjectionType().vertexSorting());
				indices = pipeline.getVertexFormat().uploadImmediateIndexBuffer(built.indexBuffer());
				indexType = built.drawState().indexType();
			} else {
				RenderSystem.AutoStorageIndexBuffer shape = RenderSystem.getSequentialBuffer(pipeline.getVertexFormatMode());
				indices = shape.getBuffer(params.indexCount());
				indexType = shape.type();
			}

			GpuBufferSlice transforms = RenderSystem.getDynamicUniforms()
				.writeTransform(RenderSystem.getModelViewMatrix(), COLOR_MODULATOR, MODEL_OFFSET, TEXTURE_MATRIX);

			try (RenderPass pass = RenderSystem.getDevice()
				.createCommandEncoder()
				.createRenderPass(
					() -> MOD_ID + " path rendering",
					client.getMainRenderTarget().getColorTextureView(),
					OptionalInt.empty(),
					client.getMainRenderTarget().getDepthTextureView(),
					OptionalDouble.empty())) {
				pass.setPipeline(pipeline);
				RenderSystem.bindDefaultUniforms(pass);
				pass.setUniform("DynamicTransforms", transforms);
				pass.setVertexBuffer(0, vertices);
				pass.setIndexBuffer(indices, indexType);
				pass.drawIndexed(0, 0, params.indexCount(), 1);
			}

			built.close();
		}

		void close() {
			allocator.close();
			if (vertexBuffer != null) {
				vertexBuffer.close();
				vertexBuffer = null;
			}
		}
	}
}
